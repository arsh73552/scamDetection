# scamDetection
Detects Scam :-)
